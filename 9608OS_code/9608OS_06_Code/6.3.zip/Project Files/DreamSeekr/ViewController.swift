//
//  ViewController.swift
//  DreamSeekr
//
//  Created by Paul Napier on 14/10/2015.
//  Copyright © 2015 Packt Publishing. All rights reserved.
//

import UIKit
import MobileCoreServices

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var textField: UITextField!
    
    
    
    @IBAction func addImage(sender: AnyObject) {
        
        let imagePicker = UIImagePickerController()
        
        imagePicker.delegate = self
        
        presentViewController(imagePicker, animated: true) { () -> Void in
            
        }
        
    }
    
    @IBAction func save(sender: AnyObject) {
        
        
    }
    
    // MARK:- View Lifecycle Methods
    
    // MARK: Called each time the view controller is created and the main UIView is about to be displayed
    
    override func loadView() {
        super.loadView()
        
        print(__FUNCTION__)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillShow:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
        
        print(__FUNCTION__)
    }
    
    // MARK: Called each time the view controller is displayed
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        print(__FUNCTION__)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        print(__FUNCTION__)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        print(__FUNCTION__)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        print(__FUNCTION__)
    }
    
    // MARK: Called each time the view controller will be hidden
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        print(__FUNCTION__)
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        
        print(__FUNCTION__)
    }
    
    // MARK: Called each time the view will move to another size class, such as through orientation or split screen
    
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        
        print(__FUNCTION__)
    }
    
    deinit{
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func keyboardWillShow(notification:NSNotification) {
        
    }
    
    func keyboardWillHide(notification:NSNotification){
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        picker.dismissViewControllerAnimated(true) { () -> Void in
            
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        picker.dismissViewControllerAnimated(true) { () -> Void in
            
            if
            let mediaType = info[UIImagePickerControllerMediaType] as? NSObject,
            let image = info[UIImagePickerControllerOriginalImage] as? UIImage,
            let imageLinkUrl = info[UIImagePickerControllerReferenceURL] as? NSURL
                where mediaType == kUTTypeImage {
                  
                   self.imageView.image = image
                    
                    let pngData = UIImagePNGRepresentation(image)
                    
                    var fileName = ""
                    
                    if let query = imageLinkUrl.query {
                        
                        let array = query.componentsSeparatedByString("&")
                        
                        for item in array where item.hasPrefix("id") || item.hasPrefix("ext") {
                            let items = item.componentsSeparatedByString("=")
                            
                            if items.count > 0 {
                                fileName += items[1]
                            }else{
                                fileName += "." + items[1].lowercaseString
                            }
                        }
                    }
                    
                    let paths = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)
                    
                    let documentsPath = paths[0] as String
                    
                    let filePath = documentsPath.stringByAppendingString("/" + fileName)
                    
                    pngData?.writeToFile(filePath, atomically: true)
                    
                    
            }
            
            
        }
    }
}

