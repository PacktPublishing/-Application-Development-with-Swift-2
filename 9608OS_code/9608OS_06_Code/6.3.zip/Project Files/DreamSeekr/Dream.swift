//
//  Dream.swift
//  DreamSeekr
//
//  Created by Paul Napier on 24/10/2015.
//  Copyright © 2015 Packt Publishing. All rights reserved.
//

import Foundation


class Dream {
    var name:String = ""
    var imageUrl:String = ""
    var created:NSDate = NSDate()
    var acheived:Bool = false
}