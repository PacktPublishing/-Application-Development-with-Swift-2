//
//  ViewController.swift
//  DreamSeekr
//
//  Created by Paul Napier on 14/10/2015.
//  Copyright © 2015 Packt Publishing. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK:- View Lifecycle Methods
    
    // MARK: Called each time the view controller is created and the main UIView is about to be displayed
    
    override func loadView() {
        super.loadView()
        
        print(__FUNCTION__)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(__FUNCTION__)
    }
    
    // MARK: Called each time the view controller is displayed
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        print(__FUNCTION__)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        print(__FUNCTION__)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        print(__FUNCTION__)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        print(__FUNCTION__)
    }
    
    // MARK: Called each time the view controller will be hidden
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        print(__FUNCTION__)
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        
        print(__FUNCTION__)
    }
    
    // MARK: Called each time the view will move to another size class, such as through orientation or split screen
    
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        
        print(__FUNCTION__)
    }
    
    
}

